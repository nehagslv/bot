# Redis queue API

> **Note:** The redis queue API is no longer supported and has been removed from Cog.
