# End to end tests

To run:

    $ pip install -r requirements.txt
    $ make test
