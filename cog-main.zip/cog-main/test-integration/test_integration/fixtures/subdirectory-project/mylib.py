def concat(a, b):
    return a + " " + b
